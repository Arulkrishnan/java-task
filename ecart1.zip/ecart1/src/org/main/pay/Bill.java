package org.main.pay;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Bill {
	@Id
  private int id;
  public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBillid() {
		return billid;
	}
	public void setBillid(int billid) {
		this.billid = billid;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
private  int billid;
  private String productName;
  private double price;
  private int discount;

  
  
}
