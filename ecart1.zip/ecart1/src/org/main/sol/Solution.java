package org.main.sol;
import java.util.*;


import org.customer.*;
import org.product.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;  
	      
	    public class Solution {  
	    public static void main(String[] args) {  
	    	 int id;
	         String name;
	        String emailid;
	         double phoneNumber;
	         String gender;
	         String dateOfBirth;
	         SessionFactory sf = new Configuration().configure().buildSessionFactory();
		    	Session session = sf.openSession();  
		          
		        session.beginTransaction();
	         for(int i=0;i<2;i++)
		        {
	    	  
	          
	        Customer c=new Customer();  
	       
	        Scanner obj=new Scanner(System.in);
	        System.out.println("id");
	        id=obj.nextInt();
	        c.setId(id);
	        System.out.println("name");
	        name=obj.next();
	        c.setName(name);
	        System.out.println("emailid");
	        emailid=obj.next();
		    c.setEmailid(emailid);
		    System.out.println("phoneNumber");
		    phoneNumber=obj.nextDouble();
		    c.setPhoneNumber(phoneNumber);
		    System.out.println("gender");
		    gender=obj.next();
		    c.setGender(gender); 
		    System.out.println("dataOfBirth");
		    dateOfBirth=obj.next();
		    c.setDateOfBirth(dateOfBirth);
	        
		      
		     specific1 c1=new specific1();
	       session.persist(c);  
	        session.persist(c1);
	        //session.persist(d);
	        session.getTransaction().commit();
	               
	    }
	         session.close();  
		        System.out.println("successfully saved");
		
	        
	          
	        
	        
	    }
	    }
